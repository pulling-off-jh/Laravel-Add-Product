

<?php $__env->startSection('title'); ?>
    MANAGE_PRODUCT
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1 class="text-center">Manage Product</h1>

<div class="container">
    <div class="row">
        <div class="col-md-12 mx-auto">

            <table class="table table-dark table-striped">
                <table class="table table-bordered">
                    <thead class="table-dark">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Category Name</th>
                        <th scope="col">Brand Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Image</th>
                        <th scope="col">Status</th>
                        <th scope="col">Edit/Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $allProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <th scope="row"><?php echo e($product->id); ?></th>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->category_name); ?></td>
                        <td><?php echo e($product->brand_name); ?></td>
                        <td><?php echo e($product->description); ?></td>
                        <td><img height="100px" width="100px" src="<?php echo e(asset("$product->image")); ?>"></td>
                        <td><?php echo e($product->status); ?></td>
                        <td><button class="btn btn-success">Edit</button>&nbsp<button class="btn btn-danger">Delete</button></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
            </table>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\xampp\htdocs\jhs\assesment-two\assesment-project\resources\views/manage-product.blade.php ENDPATH**/ ?>