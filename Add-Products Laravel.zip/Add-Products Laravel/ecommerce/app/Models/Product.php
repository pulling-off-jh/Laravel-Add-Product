<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    static $product, $image, $directory, $imageName;

    static function imageUrl($imageData){
        self::$image = $imageData->file('img');
        self::$imageName = self::$image->getClientOriginalName();
        self::$directory = 'product-image/';
        self::$image->move(self::$directory, self::$imageName);
        return self::$directory.self::$imageName;
    }

    static function insertProduct($data){
        self::$product = new product();
        self::$product->name = $data->name;
        self::$product->category_name = $data->category;
        self::$product->brand_name = $data->brand;
        self::$product->description = $data->description;
        self::$product->image = self::imageUrl($data);
        self::$product->status = $data->status;
        self::$product->save();
    }
}
