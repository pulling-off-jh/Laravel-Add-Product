@extends('master')

@section('title')
    HOME
@endsection

@section('content')

<h1 class="text-center">Home Page</h1>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div id="demo" class="carousel slide" data-bs-ride="carousel">

                <!-- Indicators/dots -->
                <div class="carousel-indicators">
                  <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
                  <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
                  <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
                </div>
              
                <!-- The slideshow/carousel -->
                <div class="carousel-inner">
                  <div class="carousel-item active">
                    <img height="600px" src="{{ asset('/') }}product-image/03.png" alt="Los Angeles" class="d-block w-100">
                  </div>
                  <div class="carousel-item">
                    <img height="600px" src="{{ asset('/') }}product-image/07.png" alt="Chicago" class="d-block w-100">
                  </div>
                  <div class="carousel-item">
                    <img height="600px" src="{{ asset('/') }}product-image/24.png" alt="New York" class="d-block w-100">
                  </div>
                </div>
              
                <!-- Left and right controls/icons -->
                <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
                  <span class="carousel-control-prev-icon"></span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
                  <span class="carousel-control-next-icon"></span>
                </button>
            </div>
        </div>
    </div>
</div>
<br><br><br>
<h1 class="text-center">Images</h1>
<br><br>
<div class="container">
    <div class="row">
        <div class="col-md-4">
            <div class="card bg-dark text-white">
                <img height="200px" src="{{ asset('/') }}product-image/24.png" class="card-img" alt="Stony Beach"/>
                <div class="card-img-overlay">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">
                    This is a wider card with supporting text below as a natural lead-in to additional
                    content. This content is a little bit longer.
                  </p>
                  <p class="card-text">Last updated 3 mins ago</p>
                </div>
              </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-dark text-white">
                <img height="200px" src="{{ asset('/') }}product-image/07.png" class="card-img" alt="Stony Beach"/>
                <div class="card-img-overlay">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">
                    This is a wider card with supporting text below as a natural lead-in to additional
                    content. This content is a little bit longer.
                  </p>
                  <p class="card-text">Last updated 3 mins ago</p>
                </div>
              </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-dark text-white">
                <img height="200px" src="{{ asset('/') }}product-image/03.png" class="card-img" alt="Stony Beach"/>
                <div class="card-img-overlay">
                  <h5 class="card-title">Card title</h5>
                  <p class="card-text">
                    This is a wider card with supporting text below as a natural lead-in to additional
                    content. This content is a little bit longer.
                  </p>
                  <p class="card-text">Last updated 3 mins ago</p>
                </div>
              </div>
        </div>
    </div>
</div>



@endsection