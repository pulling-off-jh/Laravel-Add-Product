

<?php $__env->startSection('title'); ?>
    ADD-PRODUCT
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1 class="text-center">Products</h1>
<div class="container">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h3 class="text-success"><?php echo e(Session::get('msg')); ?></h3>
            <form method="POST" action="<?php echo e(route('insert.product')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- Name input -->
                <div class="form-outline mb-4">
                    <label class="form-label" for="form4Example1">Name</label>
                    <input type="text" name="name" id="form4Example1" class="form-control" />
                </div>
                <div class="form-outline mb-4">
                    <label class="form-label" for="form4Example1">Category_Name</label>
                    <input type="text" name="category" id="form4Example1" class="form-control" />
                </div>
                <div class="form-outline mb-4">
                    <label class="form-label" for="form4Example1">Brand_Name</label>
                    <input type="text" name="brand" id="form4Example1" class="form-control" />
                </div>
              
                <!-- Email input -->
                <div class="form-outline mb-4">
                    <label class="form-label" for="form4Example3">Description</label>
                    <textarea class="form-control" name="description" id="form4Example3" rows="4"></textarea>
                </div>
              
                <!-- Message input -->
                <div class="form-outline mb-4">                  
                  <label class="form-label" for="customFile">Choose Image</label>
                    <input type="file" name="img" class="form-control" id="customFile" />
                </div>

                <div class="mb-3">
                    <label for="select" class="form-label">Status</label>
                    <select id="select" name="status" class="form-select">
                        <option>Choose an option</option>
                        <option>Available</option>
                        <option>Not Available</option>
                    </select>
                </div>
              
                <!-- Submit button -->
                <button type="submit" class="btn btn-primary btn-block mb-4">Send</button>
              </form>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BASIS-SEIP\Jahid_Hasan_327696\assesment-two\resources\views/add-product.blade.php ENDPATH**/ ?>