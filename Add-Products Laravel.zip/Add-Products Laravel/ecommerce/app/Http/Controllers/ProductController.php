<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class ProductController extends Controller
{
    public function addProduct(){
        return view('add-product');
    }
    public function manageProduct(){
        $manageProducts = new Product();
        return view('manage-product', ['allProduct' => $manageProducts->all()]);
    }
    public function insertNproduct(Request $request){
        Product::insertProduct($request);
        return redirect('/add-product')->with('msg', "Product added successfully");
        // return $request->all();
    }
}
