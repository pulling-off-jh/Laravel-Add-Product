@extends('master')

@section('title')
    MANAGE_PRODUCT
@endsection

@section('content')

<h1 class="text-center">Manage Product</h1>

<div class="container">
    <div class="row">
        <div class="col-md-12 mx-auto">

            <table class="table table-dark table-striped">
                <table class="table table-bordered">
                    <thead class="table-dark">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Category Name</th>
                        <th scope="col">Brand Name</th>
                        <th scope="col">Description</th>
                        <th scope="col">Image</th>
                        <th scope="col">Status</th>
                        <th scope="col">Edit/Delete</th>
                    </tr>
                    </thead>
                    <tbody>
                    @foreach($allProduct as $product)
                      <tr>
                        <th scope="row">{{ $product->id }}</th>
                        <td>{{ $product->name }}</td>
                        <td>{{ $product->category_name }}</td>
                        <td>{{ $product->brand_name }}</td>
                        <td>{{ $product->description }}</td>
                        <td><img height="100px" width="100px" src="{{ asset("$product->image") }}"></td>
                        <td>{{ $product->status }}</td>
                        <td><button class="btn btn-success">Edit</button>&nbsp<button class="btn btn-danger">Delete</button></td>
                    </tr>
                    @endforeach
                    </tbody>
                  </table>
            </table>

        </div>
    </div>
</div>

@endsection